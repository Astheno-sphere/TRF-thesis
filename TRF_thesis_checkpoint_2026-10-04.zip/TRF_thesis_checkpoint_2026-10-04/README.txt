TRF thesis checkpoint, 4 Oct 2026. Thesis repo HEAD: 083a217 P28: NCPeH pilot details said once (§2.2), cross-referred elsewhere (PRES-4) P29: Art 68(12) grounds argued once (§4.6); §6.2, §7.4 point there (PRES-4) P30: front matter level with body: proposisjon, Props 3-4, partition, log, Cor 1.2 conditions P31: Ch5 tightened (M4d): meta cut, rate caveat once, §5.4 conditional, Prop 3 link; docx rebuilt
Public code repo: github.com/Astheno-sphere/TRF at b99aa5f.

VERA-SNARK_Thesis_SUBMISSION.docx / .md  current full thesis (generated; never hand-edit the .md)
CHANGE_TRAIL.md   every change, newest first
REVIEW_TRACKER.md João's 40 review items and their status
TIGER_TASKS.md    your open tasks
thesis_repo.bundle the whole working repository with history. Restore with:
    git clone thesis_repo.bundle thesis   (then: git log, git diff joao-base-v1 -- Chapter5_Demonstration_v1.md)
