# Merge of search-round numbering: fork rounds 5-6 (22 Sept) + main round 7 (28 Sept). Fork T-27..T-35, N-06 not replayed literally; this patch supersedes them.
EDITS = [{'file': 'Appendix_B_Search_Log.md',
  'id': 'R-a',
  'new': '## Round 5: 22 September 2026 (drift verification and jeopardy check)\n'
         '\n'
         '60. `EHDS Regulation 2025/327 Article 19 digital health authority designate date Member States` *[R]*\n'
         '61. `arXiv 2607.05518 aiAuthZ` *[R]*\n'
         '62. `arXiv 2606.23696 privacy engineering systematic literature review` *[R]*\n'
         '63. `EHDS implementing act secure processing environment draft 2026 Article 73`\n'
         '\n'
         '## Round 6: 22 September 2026 (Article 68(12) primary text, D7.4 full-text check, case-law currency)\n'
         '\n'
         '64. `TEHDAS2 D7.4 technical specification secure processing environments zenodo` *[R]*\n'
         '65. `Regulation 2025/327 Article 68(12) "within six months after the expiry of the data permit" text` *[R]*\n'
         '66. `EHDS Article 68 data permit paragraph 12 "secure processing environment" delete "six months" wording` *[R]*\n'
         '67. `CJEU C-413/23 P EDPS v SRB judgment pseudonymised data personal data recipient September 2025`\n'
         '68. `Digital Omnibus GDPR personal data definition amendment status 2026 Parliament Council`\n'
         '69. `2026 paper audit log retention right to erasure conflict cryptographic erasure health data secure processing environment`\n'
         '70. `IHE ATNA audit message XCPD patient discovery ParticipantObjectQuery demographics audit record content` *[R]*\n'
         '\n'
         '## Round 7: 28 September 2026 (locator verification and source-standing audit) *[R]*',
  'old': '## Round 5: 28 September 2026 (locator verification and source-standing audit) *[R]*',
  'why': 'Fork rounds 5 and 6 (22 Sept) inserted in date order; main 28 Sept audit becomes Round 7'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t77', 'new': '\n| 88 | ', 'old': '\n| 77 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t76', 'new': '\n| 87 | ', 'old': '\n| 76 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t75', 'new': '\n| 86 | ', 'old': '\n| 75 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t74', 'new': '\n| 85 | ', 'old': '\n| 74 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t73', 'new': '\n| 84 | ', 'old': '\n| 73 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t72', 'new': '\n| 83 | ', 'old': '\n| 72 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t71', 'new': '\n| 82 | ', 'old': '\n| 71 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t70', 'new': '\n| 81 | ', 'old': '\n| 70 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t69', 'new': '\n| 80 | ', 'old': '\n| 69 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t68', 'new': '\n| 79 | ', 'old': '\n| 68 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t67', 'new': '\n| 78 | ', 'old': '\n| 67 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t66', 'new': '\n| 77 | ', 'old': '\n| 66 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t65', 'new': '\n| 76 | ', 'old': '\n| 65 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t64', 'new': '\n| 75 | ', 'old': '\n| 64 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t63', 'new': '\n| 74 | ', 'old': '\n| 63 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t62', 'new': '\n| 73 | ', 'old': '\n| 62 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t61', 'new': '\n| 72 | ', 'old': '\n| 61 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-t60', 'new': '\n| 71 | ', 'old': '\n| 60 | ', 'why': 'Round 7 targets renumbered after the 70 logged queries'},
 {'file': 'Appendix_B_Search_Log.md', 'id': 'R-b', 'new': '*Round 7 outcome:', 'old': '*Round 5 outcome:', 'why': 'Round 7 label'},
 {'file': 'Appendix_B_Search_Log.md',
  'id': 'R-c',
  'new': '*Total distinct queries logged: 70 discovery and verification queries across six rounds, plus 18 locator verifications in round 7.*',
  'old': '*Total distinct queries logged: 59 discovery and verification queries across four rounds, plus 18 locator verifications in round 5.*',
  'why': 'Totals'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md',
  'id': 'R-d',
  'new': '| 4 | 16 September 2026 | Adversarial novelty testing, prior art, final currency | 23 |\n'
         '| 5 | 22 September 2026 | Drift verification and jeopardy check before submission | 4 |\n'
         '| 6 | 22 September 2026 | Primary-source check of Article 68(12) and D7.4; currency of case law | 7 |\n'
         '| 7 | 28 September 2026 | Locator verification and source-standing audit of the bibliography | 18 targets, no discovery queries |\n'
         '| | | **Total** | **70 queries, plus 18 verification targets** |',
  'old': '| 4 | 16 September 2026 | Adversarial novelty testing, prior art, final currency | 23 |\n| | | **Total** | **59** |',
  'why': 'Joao minor issue (text said four rounds, appendix listed more); table completed'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md', 'id': 'R-e', 'new': 'This review proceeded iteratively across seven dated rounds,', 'old': 'This review proceeded iteratively across four dated rounds,', 'why': 'Count'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md',
  'id': 'R-f',
  'new': 'Every query in rounds 1 to 6 is reproduced verbatim, by round, in Appendix B; round 7 contained no discovery queries and is recorded there by target.',
  'old': 'Every query in rounds 1 to 4 is reproduced verbatim, by round, in Appendix B.',
  'why': 'Count'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md',
  'id': 'R-g',
  'new': "Round 4 also produced a correction to the thesis's own headline claim, recorded in Chapter 4, Section 4.6. Round 5 was a pre-submission check for developments and rivals that might defeat the claim; it "
         'located one design converging on the invalidation pattern and one review corroborating the gap, both reported in Sections 2.4 and 2.9, and it corrected a secondary-source date in Section 2.2 against the '
         "primary text. Round 6 returned to the primary text of Article 68(12) and read the Joint Action's 2026 specification in full, which corrected the thesis's own statement of that provision and narrowed the "
         'absence claim of Section 2.9. Round 7 verified a locator and the standing of every bibliography entry that lacked one, and removed two entries citing documents that do not exist as cited.',
  'old': "Round 4 also produced a correction to the thesis's own headline claim, recorded in Chapter 4, Section 4.6.",
  'why': 'Purpose of rounds 5-7 (fork N-06e + T-35, merged with main round 7)'},
 {'file': 'Front_Matter_v1.md',
  'id': 'R-h',
  'new': 'Search query log: 70 queries across six dated rounds, and a seventh round of 18 locator verifications',
  'old': 'Search query log: 59 queries across four dated rounds',
  'why': 'TOC count'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md', 'id': 'R-i', 'new': 'rests on six dated search rounds, three of them adversarial', 'old': 'rests on four dated rounds, two of them adversarial', 'why': 'Count (fork N-06f)'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md', 'id': 'R-j', 'new': 'rests primarily on the six documented search rounds', 'old': 'rests primarily on the four documented search rounds', 'why': 'Count (fork N-06g)'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md', 'id': 'R-k', 'new': 'Rounds 2, 4 and 5 were adversarial in intent.', 'old': 'Rounds 2 and 4 were adversarial in intent.', 'why': 'Round 5 was adversarial (jeopardy check)'}]