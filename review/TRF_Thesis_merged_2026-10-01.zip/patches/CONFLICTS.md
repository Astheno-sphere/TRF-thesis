# Merge conflicts for Tiger's decision

Each entry: the fork's version, the main line's version, the evidence, my recommendation. Nothing here is applied until Tiger chooses.

## C-1 · Chapter 1 opening (H-01 exists twice)
- **Fork, 22 Sept (turn 7):** "In Bodø and Stjørdal, Norway's gateway to European cross-border health data is live, connected to Portugal, Czechia, and Finland. By the Directorate's own reporting, no relevant patient had yet presented… (Helsedirektoratet, 2026a)…" then the Art 73(1)(e)/68(12) collision, hedged "on one reading" and "once incorporated into the EEA Agreement". Later corrected by T-02 to the provision's true object.
- **Main, 29 Sept:** see §1.1 opening in the current file.
- **Factual disagreement:** Finland in or out of the connected-countries list. Must be settled against Helsedirektoratet (2026) before either text is kept.
