# Fork pass 3 follow-up (turn 17): guideline name attributed to the right deliverable.
EDITS=[dict(id='T-07b',file='Chapter2_LitReview_v2_FINAL.md',why='TEHDAS2 (2025) is D6.3, the guideline on procedures and formats for data access, not guidance on using data in an SPE',
 old="The Joint Action's guidance on using data within such an environment treats deletion at permit closure as an operational service (TEHDAS2, 2025).",
 new="The Joint Action's guideline on procedures and formats for data access treats deletion at permit closure as an operational service (TEHDAS2, 2025).")]
