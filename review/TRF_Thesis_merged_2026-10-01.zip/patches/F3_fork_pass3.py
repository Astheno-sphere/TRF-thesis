# Auto-converted from fork transcript turn 17 (pass 3), with MERGE anchor fixes and extras M3-a/b.
# Skipped: T-02 (edits the fork's H-01 hook, conflict C-1), T-27..T-35 (search-round renumbering, handled in one combined patch).
EDITS = [{'file': 'Front_Matter_v1.md',
  'id': 'T-01',
  'new': 'a collision internal to a single regulation. That specific result holds for log records that themselves carry electronic health data, and is conditional on a reading of Article 68(12)',
  'old': 'a collision internal to a single regulation. That specific result is conditional on a reading of Article 68(12)',
  'why': 'Abstract Front: Art 68(12) reaches electronic health data, not personal data at large'},
 {'file': 'Chapter1_Introduction_v2.md',
  'id': 'T-03',
  'new': 'Identifiable access logs are personal data, and a log that records the parameters of a query run against the permitted dataset also carries electronic health data. Article 68(12) provides '
         'that *the electronic health data within the secure processing environment shall be deleted within six months of the expiry of the data permit*. Chapter 4, Section 4.6 defends a reading '
         'under which that obligation attaches by location, reaching electronic health data wherever it sits in the environment and so the health-data content of the logs, rather than only the '
         'dataset supplied under the permit. On that reading, the Regulation requires of a single environment that this content be gone within six months of permit expiry while the identifiable log '
         'itself is retained for at least twelve months.',
  'old': 'Identifiable access logs are personal data, and they are data within the environment. Chapter 4, Section 4.6 defends a reading of Article 68(12) under which the provision governs the data '
         'within the secure processing environment rather than only the dataset supplied under the permit. On that reading, the Regulation requires of a single environment that data be removed '
         'within six months of permit expiry and that identifiable logs be retained for at least twelve months.',
  'why': '§1.1 Ch1: Misquote corrected; claim scoped to logs carrying EHD'},
 {'file': 'Chapter1_Introduction_v2.md',
  'id': 'T-04',
  'new': 'then requires deletion of the electronic health data in the environment within six months of permit expiry.',
  'old': 'then requires deletion of personal data from the environment within six months of permit expiry.',
  'why': '§1.2 Ch1: Exact object'},
 {'file': 'Chapter1_Introduction_v2.md',
  'id': 'T-05',
  'new': 'On the broad reading, the environment must therefore be emptied of electronic health data at six months, the health-data content of its own logs included, while continuing to hold for a '
         'further six months at minimum the identifiable record of who accessed what within it.',
  'old': 'On the broad reading, the environment must therefore be emptied of personal data at six months while continuing to hold, for a further six months at minimum, identifiable records of who '
         'accessed what within it.',
  'why': '§1.2 Ch1: Exact object'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md',
  'id': 'T-06',
  'new': 'Identifiable access logs are personal data, and a log that records the parameters of a query run against the permitted dataset also carries electronic health data. Article 68(12) provides, '
         'in terms, that *the electronic health data within the secure processing environment shall be deleted within six months of the expiry of the data permit*. The obligation is framed by '
         'location rather than by provenance, so that on the reading adopted here it attaches to electronic health data wherever it sits in the environment, including the health-data content of the '
         'logs, and not only to the dataset supplied under the permit. The Regulation then requires of one environment both that this content be gone six months after permit expiry and that the '
         'identifiable log persist for at least twelve months. The reading is contestable (the provision sits within the data-permit article, a narrower construction confines it to the permitted '
         'dataset, and the identifying element of a bare access log is the health data user rather than the patient), and Chapter 4, Section 4.6 states the grounds on both sides and shows which '
         'results depend on which.',
  'old': 'Identifiable access logs are personal data and are data within the environment. Article 68(12) governs, in terms, the data within the secure processing environment rather than only the '
         'dataset supplied under the permit; on that reading the Regulation requires of one environment both that data be removed within six months of permit expiry and that identifiable logs '
         'persist for at least twelve months. The reading is contestable (the provision sits within the data-permit article, and a narrower construction confines it to the permitted dataset) and '
         'Chapter 4, Section 4.6 states the grounds on both sides and shows which results depend on which.',
  'why': '§2.3 Ch2: Misquote corrected; scope stated | MERGE: anchor adjusted for main em-dash pass (dash pair -> parentheses) | MERGE: em-dash pair rendered as parentheses to match main E-05'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md',
  'id': 'T-07',
  'new': "The Joint Action's guidance on using data within such an environment treats deletion at permit closure as an operational service (TEHDAS2, 2025). The specification itself comes closer than "
         'that, and the claim made here is correspondingly narrow. It requires both that all logs of a Secure Processing Environment be kept for at least one year and that the electronic health data '
         'in the environment be deleted or rendered unrecoverable within six months of permit expiry, backups and redundant copies included, while complying with applicable legal obligations and '
         'with traceability or reproducibility requirements where relevant. It states in general terms that termination and deletion must be balanced against logging, auditability and exceptions '
         "mandated by law (TEHDAS2, 2026). What it does not do is say how the six-month obligation and the twelve-month floor are to be satisfied together where the log's own content is electronic "
         'health data, or specify any mechanism for doing so. Two features of that text bear on the design proposed here. The deletion obligation is discharged by rendering data unrecoverable as '
         'much as by erasing it, which is the corridor a cryptographic mechanism occupies. And the specification cautions against logging user-behaviour detail beyond what auditability requires, '
         "which is the minimisation the model's decomposition assumes.",
  'old': "The Joint Action's guidance on using data within such an environment treats deletion at permit closure as an operational service. Neither connects that deletion obligation to the one-year "
         'identifiable-log retention floor imposed on the same environment by Article 73(1)(e) (TEHDAS2, 2025, 2026). The body drafting the specifications for both provisions has not addressed their '
         'interaction.',
  'why': '§2.6 Ch2: D7.4 read in full 22 Sept: it states both obligations and defers; previous claim was too strong'},
 {'file': 'Chapter2_LitReview_v2_FINAL.md',
  'id': 'T-08',
  'new': 'The review conducted for this thesis located no treatment of it in the academic literature or in the professional commentary on EHDS secondary use. The guidance published by the Joint '
         'Action drafting the specifications for both provisions comes closer: its 2026 specification states both obligations and says in general terms that deletion must be balanced against '
         "logging, auditability and exceptions mandated by law, without addressing the case where a log's own content is electronic health data and without specifying a mechanism (TEHDAS2, 2026). "
         'What is claimed absent is therefore a resolution, not an awareness.',
  'old': 'The review conducted for this thesis located no treatment of it: not in the academic literature, not in the professional commentary on EHDS secondary use, and not in the guidance published '
         'by the Joint Action drafting the specifications for both provisions.',
  'why': '§2.9 Ch2: Same correction, gap claim narrowed'},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-09',
  'new': 'Electronic health data must not remain accessible in the Secure Processing Environment more than six months after permit expiry.',
  'old': 'Personal data must not remain accessible in the Secure Processing Environment more than six months after permit expiry.',
  'why': '§4.4 C3 Ch4: Exact object'},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-10',
  'new': 'Article 73(1)(e) requires the identifiable log to remain verifiable for twelve months, and Article 68(12) requires the electronic health data in the environment, which on the reading '
         'defended below includes the health data the log itself carries, to be gone six months after permit expiry.',
  'old': 'Article 73(1)(e) requires the identifiable log to remain verifiable for twelve months, and Article 68(12) requires personal data to be gone from the environment six months after permit '
         'expiry.',
  'why': '§4.6 Cor 1.2 Ch4: Exact object'},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-11',
  'new': 'The provision reads: *the electronic health data within the secure processing environment shall be deleted within six months of the expiry of the data permit*. Two features of that wording '
         'matter. It is framed by location rather than by provenance: it does not say "the data made available under the data permit," though the Regulation uses that narrower formulation freely '
         'elsewhere. And its object is electronic health data, not personal data at large. The broad reading adopted here follows from the first feature. The obligation attaches to electronic health '
         'data wherever it sits in the environment, and a log that records the parameters of a query run against the permitted dataset carries such data. On that reading Article 68(12) reaches the '
         'health-data content of the log, and Corollary 1.2 follows for log records of that kind.\n'
         '\n'
         'The second feature bounds the claim, and it is why the corollary is stated for log records that carry electronic health data rather than for access logs at large. The identifying element '
         'of a bare access log is the health data user: a record that a named researcher logged in at a given hour is personal data about that researcher, not health data about a patient. Article '
         '68(12) does not reach it, and Article 73(1)(e) requires it to be kept. Read this way the two provisions address different components of the same record, and they divide it along exactly '
         'the line the necessity analysis of Section 4.2 draws: Article 73(1)(e) governs the accountability metadata $m(a)$, and Article 68(12) governs the health-data payload $p(a)$. Under '
         'Semantics I, which treats the record as one indivisible unit, that division is invisible and the provisions collide. Under Semantics II the division is the design.',
  'old': 'The textual case for the broad reading is that the provision governs *the data within the secure processing environment*, a formulation defined by location rather than by provenance. It '
         'does not say "the data made available under the data permit," though the Regulation uses that narrower formulation freely elsewhere, and the access logs are indisputably data within the '
         'environment. On that reading Article 68(12) reaches them, and Corollary 1.2 follows.',
  'why': "§4.6 Ch4: Exact text; narrower and stronger reading, matching the model's decomposition | MERGE: anchor adjusted for main em-dash pass"},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-12',
  'new': "The Joint Action's 2026 specification shows how the question is being handled in practice rather than answering it. It requires the electronic health data in the environment to be deleted "
         'or rendered unrecoverable within six months of permit expiry, backups included, and separately requires all logs to be kept for at least a year, reconciling the two only by a general '
         'deference to applicable legal obligations and to traceability requirements (TEHDAS2, 2026). That is consistent with either reading.\n'
         '\n'
         'This thesis adopts the broad reading and states the grounds rather than asserting the conclusion.',
  'old': 'This thesis adopts the broad reading and states the grounds rather than asserting the conclusion.',
  'why': '§4.6 Ch4: D7.4 evidence, neutral'},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-13',
  'new': '*Two developments since the Norwegian guidance was written.* The threshold applied above comes from guidance issued in 2015, and the Union-level test has since become relative rather than '
         'absolute. In *EDPS v SRB* the Court of Justice held that pseudonymised data is not automatically personal data for every actor, and that where the risk of a recipient having reasonable '
         'means to re-identify is insignificant the data may fall outside the definition for that recipient (Court of Justice of the European Union, 2025). The consequence here is asymmetric and '
         'modest. For the controller, which retains the metadata identifying the access event, the residue remains personal data and the characterisation above is unchanged. For an external auditor '
         'given commitments, invalidation entries and ciphertext, without key material or identifying metadata, the residue may fall outside the definition; that bears on what an audit may be given, '
         "not on what the controller holds. Separately, the Joint Action's specification for Secure Processing Environments treats the deletion obligation as discharged where data are deleted *or "
         'rendered unrecoverable*, backups included (TEHDAS2, 2026), which is the corridor this mechanism is built for.\n'
         '\n'
         '*The trust assumptions, stated explicitly.*',
  'old': '*The trust assumptions, stated explicitly.*',
  'why': '§4.9 Ch4: CJEU C-413/23 P (4 Sept 2025) and D7.4; neither overstated'},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-14',
  'new': 'The specification published by TEHDAS2 during 2026 as deliverable D7.4 is the best available anticipation of their content (TEHDAS2, 2026). Its treatment of deletion is permissive in the '
         'way this mechanism requires: the obligation is discharged where electronic health data are deleted or rendered unrecoverable, backups included.',
  'old': 'The specification published by TEHDAS2 during 2026 as deliverable D7.4 is the best available anticipation of their content (TEHDAS2, 2026).',
  'why': '§4.11 Ch4: D7.4 support'},
 {'file': 'Chapter4_TRF_Model_v1.md',
  'id': 'T-15',
  'new': '\n'
         'Court of Justice of the European Union. (2025). *European Data Protection Supervisor v Single Resolution Board* (Case C-413/23 P), judgment of 4 September 2025, ECLI:EU:C:2025:645 [Press '
         'release No 107/25]. https://curia.europa.eu/site/upload/docs/application/pdf/2025-09/cp250107en.pdf\n'
         '\n'
         'Datatilsynet. (2015).',
  'old': '\nDatatilsynet. (2015).',
  'why': 'References Ch4: Reference for T-13'},
 {'file': 'Chapter5_Demonstration_v1.md',
  'id': 'T-16',
  'new': '- *Secure Processing Environment access-log records*, `F = 12` months, secondary pathway. Their payload stands for the electronic health data such a log carries, which is what Article '
         '68(12) reaches on the reading defended in Chapter 4, Section 4.6; their metadata stands for the identifiable element Article 73(1)(e) requires to be kept.',
  'old': '- *Secure Processing Environment access-log records*, `F = 12` months, secondary pathway.',
  'why': '§5.2 Ch5: Record class scoped'},
 {'file': 'Chapter5_Demonstration_v1.md',
  'id': 'T-17',
  'new': "so Article 68(12) requires the electronic health data in the environment, this log's own health-data content included, to be gone by month sixteen",
  'old': 'so Article 68(12) requires personal data to be gone from the environment by month sixteen',
  'why': '§5.4 Ch5: Exact object'},
 {'file': 'Chapter5_Demonstration_v1.md',
  'id': 'T-18',
  'new': 'On the reading of Article 68(12) adopted in Chapter 4, Section 4.6, and for log records that carry electronic health data, the conflict is internal to Regulation (EU) 2025/327. Under the '
         'narrower reading canvassed there, or for logs recording only who entered the environment and when, these thirty-nine witnesses lapse',
  'old': 'On the reading of Article 68(12) adopted in Chapter 4, Section 4.6, the conflict is internal to Regulation (EU) 2025/327. Under the narrower reading canvassed there, these thirty-nine '
         'witnesses lapse',
  'why': '§5.4 Ch5: Scope stated at the witnesses'},
 {'file': 'Chapter6_Discussion_v1.md',
  'id': 'T-19',
  'new': 'Article 68(12) requires the electronic health data in that environment to be deleted within six months of the expiry of the data permit. Identifiable logs are personal data, and a log that '
         'records the parameters of a query run against the permitted dataset also carries electronic health data.',
  'old': 'Article 68(12) requires personal data to be deleted from that environment within six months of the expiry of the data permit. Identifiable access logs are personal data.',
  'why': '§6.1 Ch6: Exact object'},
 {'file': 'Chapter6_Discussion_v1.md',
  'id': 'T-20',
  'new': 'Article 68(12) governs the electronic health data within the secure processing environment shall be deleted within six months of the expiry of the data permit, and the thesis reads that '
         'obligation as attaching by location, so that it reaches the health-data content of the logs the environment generates and not only the dataset supplied under the permit. The claim '
         'therefore holds for log records carrying electronic health data, not for bare access logs, whose identifying element is the health data user rather than the patient.',
  'old': 'Article 68(12) governs *the data within the secure processing environment*, and the thesis reads that as reaching the identifiable access logs the environment generates rather than only '
         'the dataset supplied under the permit.',
  'why': '§6.1 Ch6: Exact text and scope'},
 {'file': 'Chapter6_Discussion_v1.md',
  'id': 'T-21',
  'new': 'Against Article 68(12), which requires that electronic health data not remain in the environment,',
  'old': 'Against Article 68(12), which requires that personal data not remain in the environment,',
  'why': '§6.4 Ch6: Exact object'},
 {'file': 'Chapter6_Discussion_v1.md',
  'id': 'T-22',
  'new': 'the 2026 specification states both obligations, accepts deletion and rendering unrecoverable as equivalent modes of discharge, and reconciles them only by deference to applicable legal '
         "obligations. The case where a log's own content is electronic health data is left unspecified, and it is that case an implementing act must reach.",
  'old': 'the collision is presently unaddressed in guidance that treats deletion at permit closure as an operational service.',
  'why': '§6.8 Ch6: D7.4 read in full'},
 {'file': 'Chapter7_Conclusion_v1.md',
  'id': 'T-23',
  'new': 'The second concerns scope. Article 68(12) governs *the electronic health data within the secure processing environment shall be deleted within six months of the expiry of the data permit*. '
         'The thesis reads that as attaching by location, and so as reaching the health-data content of the logs an environment generates, on the grounds that the provision is framed by location '
         'rather than provenance and that the Regulation uses the narrower "made available under the data permit" formulation elsewhere when it means it. Because the object of the obligation is '
         'electronic health data rather than personal data at large, the claim is confined to logs carrying such data; a record of who entered the environment and when is personal data about the '
         'health data user and falls outside it.',
  'old': 'The second concerns scope. Article 68(12) governs *the data within the secure processing environment*. The thesis reads that as reaching the identifiable access logs the environment '
         'generates, on the grounds that the provision is framed by location rather than provenance and that the Regulation uses the narrower "made available under the data permit" formulation '
         'elsewhere when it means it.',
  'why': '§7.4 Ch7: Exact text and scope'},
 {'file': 'Chapter7_Conclusion_v1.md',
  'id': 'T-24',
  'new': 'and whether Article 68(12) reaches the health-data content of the logs an environment generates) has a determinate answer.',
  'old': 'and whether Article 68(12) reaches access logs) has a determinate answer.',
  'why': '§7.4 Ch7: Scope | MERGE: anchor adjusted, main converted the dash pair to parentheses'},
 {'file': 'Appendix_C_Evaluation_Instrument.md',
  'id': 'T-25',
  'new': '7. Article 68(12) requires that "the electronic health data within the secure processing environment" be deleted within six months of permit expiry. Does that reach the health-data content '
         'of the logs the environment generates, or only the dataset supplied under the permit?',
  'old': '7. Article 68(12) governs "the data within the secure processing environment." Does that reach the access logs the environment generates, or only the dataset supplied under the permit?',
  'why': '§C.5 Q7 App C: Exact text'},
 {'file': 'Appendix_C_Evaluation_Instrument.md',
  'id': 'T-26',
  'new': 'Article 68(12) should be read as reaching the health-data content of the logs generated within a Secure Processing Environment.',
  'old': 'Article 68(12) should be read as reaching the access logs generated within a Secure Processing Environment.',
  'why': '§C.6 R3 App C: Scope'},
 {'file': 'Chapter3_Methodology_v1.md',
  'id': 'M3-a',
  'new': 'whether Article 68(12) reaches the health-data content of the logs an environment generates',
  'old': 'whether Article 68(12) reaches the access logs an environment generates',
  'why': 'MERGE extra: same object correction as T-25, missed by the fork'},
 {'file': 'Chapter6_Discussion_v1.md',
  'id': 'M3-b',
  'new': 'whether Article 68(12) reaches the health-data content of the logs an environment generates',
  'old': 'whether Article 68(12) reaches the access logs an environment generates',
  'why': 'MERGE extra: same object correction as T-25, missed by the fork'}]