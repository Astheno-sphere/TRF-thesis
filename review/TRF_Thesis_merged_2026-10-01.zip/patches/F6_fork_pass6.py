# Replay of fork pass 6 (turn 35): Rak (2024) and the two figures.
# Not replayed: P6-01 (relabel D6.3 to the final 2026 version). Main's C-07 cites D6.3 v1.5 as the
# version actually read, with its draft status stated; relabelling to a version whose content was
# not re-read would cite what was not inspected. Kept main's position.
# MERGE corrections, verified 30 Sept against the article abstract (private-law-theory.org mirror of EJRR 15(4) 928-938):
#   the abstract says ambiguity "could lead to" inconsistent practice (fork: "will produce");
#   the paper predates formal adoption (Dec 2024), which is now stated.
# Figures rebuilt from the fork's SVG source and corrected after rendering: stacked labels ran
# bottom-to-top in Fig 1; arrows struck through the transition labels in Fig 2; 2035 labelled
# "Art 75(5) applies" per Art 105 (fork: "further milestones"); titles removed from the images
# because the caption carries them. Paths use figures/ so chapters and the assembly both resolve.
RAK="Rak, R. (2024). Anonymisation, pseudonymisation and secure processing environments relating to the secondary use of electronic health data in the European Health Data Space (EHDS). *European Journal of Risk Regulation*, *15*(4), 928–938. https://doi.org/10.1017/err.2024.67"
EDITS=[
 dict(id='P6-02',file='Chapter2_LitReview_v2_FINAL.md',why='Rak (2024): peer-reviewed support that the EHDS definition of electronic health data is ambiguous',
  old="and Chapter 4, Section 4.6 states the grounds on both sides and shows which results depend on which.",
  new="and Chapter 4, Section 4.6 states the grounds on both sides and shows which results depend on which. That the question is open is not this author's observation alone: writing before the Regulation's formal adoption, Rak (2024) concludes that the EHDS has been drafted ambiguously and gives its definition of electronic health data as an example, which is precisely the term on which the reach of Article 68(12) turns."),
 dict(id='P6-02r',file='Chapter2_LitReview_v2_FINAL.md',why='Reference for P6-02',old="\nReardon, J., Basin, D.,",new="\n"+RAK+"\n\nReardon, J., Basin, D.,"),
 dict(id='P6-03',file='Chapter4_TRF_Model_v1.md',why='Rak in the interpretive block',
  old="Under Semantics I, which treats the record as one indivisible unit, that division is invisible and the provisions collide. Under Semantics II the division is the design.",
  new="Under Semantics I, which treats the record as one indivisible unit, that division is invisible and the provisions collide. Under Semantics II the division is the design. The weight this reading has to carry is itself a symptom of the drafting: Rak (2024), reviewing the secondary-use framework, concludes that the Regulation has been drafted ambiguously, names the definition of electronic health data as an example, and warns that this could lead to inconsistent practice. The interpretive question identified here is therefore one the peer-reviewed literature independently anticipates, which is a reason to put it to a supervisory authority rather than to settle it by argument."),
 dict(id='P6-03r',file='Chapter4_TRF_Model_v1.md',why='Reference for P6-03',old="\nScope, N., Rasin, A., Lenard, B., Heart,",new="\n"+RAK+"\n\nScope, N., Rasin, A., Lenard, B., Heart,"),
 dict(id='P6-04',file='Chapter6_Discussion_v1.md',why='Figure 1 (implementation window); Joao minor: thesis had zero figures',
  old="The collision this thesis characterises is therefore not yet operative, and the specifications that will determine how it is handled are not yet written.",
  new="Figure 1 sets the dates out.\n\n![Figure 1. The implementation window: EHDS milestones against this thesis.](figures/figure1_regulatory_timeline.png)\n\nThe collision this thesis characterises is therefore not yet operative, and the specifications that will determine how it is handled are not yet written."),
 dict(id='P6-05',file='Chapter4_TRF_Model_v1.md',why='Figure 2 (record states)',
  old="*Applying the mechanism to the two cases.*",
  new="Figure 2 shows the three states a record passes through and what survives in each.\n\n![Figure 2. States of an audit record under Crypto-Erasure by Invalidation.](figures/figure2_record_states.png)\n\n*Applying the mechanism to the two cases.*"),
]
