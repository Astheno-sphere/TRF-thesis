# Replay of fork (chat 2a87fc70) pass 1, 22 Sept 2026, onto the 29 Sept canonical line.
# Source: fork transcript turn 5 (/tmp/edits.py). Differences from the fork are marked MERGE.
# Not replayed here: D-02 (already fixed on main as C-18), D-04/D-05 (reached main via repo sync),
# N-05 (TEHDAS2 labels; superseded by fork P6-01, handled with the reference-list merge),
# N-06 (search-round renumbering; conflicts with main's 28 Sept Round 5, handled separately).
C2 = 'Chapter2_LitReview_v2_FINAL.md'; C4 = 'Chapter4_TRF_Model_v1.md'; C = 'Appendix_C_Evaluation_Instrument.md'
EDITS = [
 dict(id='D-01', file=C2, why='EY tax alert contradicted the OJ; Art 19(1) re-verified 30 Sept (streamlex mirror of OJ text)',
  old="Each Member State must designate a National Digital Health Authority by June 2025, and healthcare providers and electronic health record vendors must certify their systems for interoperability and security compliance by January 2026 (Ernst & Young, 2025).",
  new="Under Article 19(1), each Member State must designate one or more digital health authorities for primary use and inform the Commission of their identity by 26 March 2027 (European Parliament and Council of the European Union, 2025)."),
 dict(id='D-01b', file=C2, why='EY no longer cited after D-01',
  old="Ernst & Young. (2025). *Regulation (EU) 2025/327: Establishing the European Health Data Space (EHDS)* [Law alert]. EY Greece. https://www.ey.com/en_gr/technical/tax/tax-alerts/regulation-2025-327-establishing-ehds\n\n",
  new=""),
 dict(id='D-03a', file=C4, why='Section 4.10 treats five rivals (Rival 5 = DePaul)', old="Four are treated here", new="Five are treated here"),
 dict(id='D-03b', file=C4, why='Same', old="Four rival designs were considered", new="Five rival designs were considered"),
 dict(id='D-06a', file=C, why='Execution status is Section 3.8 (MERGE: anchor adjusted, main added C.1a text after it)',
  old="Its execution status is stated in Chapter 3, Section 3.9.", new="Its execution status is stated in Chapter 3, Section 3.8."),
 dict(id='D-06b', file=C, why='No-human-participants statement is Section 3.9',
  old="Chapter 1, Section 1.5, Chapter 3, Section 3.8, and the Declaration", new="Chapter 1, Section 1.5, Chapter 3, Section 3.9, and the Declaration"),
 dict(id='N-01', file=C2, why='aiAuthZ; re-verified 30 Sept against arXiv HTML s3.1, s3.4 (redaction pass, unsalted digests)',
  old="and Section 2.9 states them as gaps with this precision.",
  new="and Section 2.9 states them as gaps with this precision.\n\nA 2026 systems preprint shows the same pattern converging from a different domain, and it narrows the second of those deltas without closing it. Kodathala (2026) describes aiAuthZ, an authorisation gateway for AI agents whose audit log is a SHA-256 hash chain with retention by crypto-erasure. A redaction pass clears the encrypted payload columns of rows past their retention period, and data-subject erasure clears payloads in the same way; rows are never deleted, and the redaction is itself appended to the chain, so that the fact and outcome of every decision remain provable after the payload is gone. That is structurally close to the invalidation entry of Chapter 4, and it means the second delta must be narrowed: at least one published design records erasure as a chained event rather than merely asserting it. Three differences remain. The design is bi-lateral, a retention period and an erasure right with no deletion ceiling. It offers no formal model within which its reconciliation is derived. And its row hashes cover content digests that the paper does not describe as salted, whereas Chapter 4, Section 4.9 shows why a surviving digest of a low-entropy clinical payload must be hiding. The work is a single-author preprint and has not been peer-reviewed; it is cited as evidence of convergent practice, not as authority."),
 dict(id='N-02', file=C2, why='Borovits et al. SLR; re-verified 30 Sept (s2.1, s2.2, s3.2, s3.3.12). MERGE: fork said lifecycle management "never" primary and added an unverified clause; corrected to the paper\'s wording',
  old="the preprint is consistent with that finding and does not carry it.",
  new="the preprint is consistent with that finding and does not carry it.\n\nA second and independent source points the same way and carries different weight. Borovits, Tamburri, and van den Heuvel (2026) synthesise ninety privacy-engineering studies published between May 2018 and March 2025. Lifecycle management of retention and deletion is among the dimensions they find are less often a study's primary focus, and they report that evidence on recovery from conflicting obligations, their example being a legal hold against an erasure request, remained limited. They also observe that several systems combined deletion with persistent audit by storing proofs of action alongside content removal, which is the family to which the invalidation entry of Chapter 4 belongs. The review is itself a preprint, and its corpus closes in March 2025, the month in which the EHDS Regulation entered into force. What it establishes is that the privacy-engineering literature treats the resolution of retention–erasure conflicts as under-evidenced; it does not establish that the tri-lateral case specifically is untreated, and it is not cited for that."),
 dict(id='N-03', file=C2, why='Reference for N-02',
  old="Brunner, S., Johannessen, A.",
  new="Borovits, N., Tamburri, D. A., & van den Heuvel, W.-J. (2026). *Privacy engineering: A systematic literature review* (arXiv:2606.23696) [Preprint]. arXiv. https://doi.org/10.48550/arXiv.2606.23696\n\nBrunner, S., Johannessen, A."),
 dict(id='N-04', file=C2, why='Reference for N-01',
  old="\nMatheson. (2026)",
  new="\nKodathala, S. V. (2026). *aiAuthZ: Off-host, identity-bound authorization for AI agents* (arXiv:2607.05518) [Preprint; not peer-reviewed]. arXiv. https://doi.org/10.48550/arXiv.2607.05518\n\nMatheson. (2026)"),
]
